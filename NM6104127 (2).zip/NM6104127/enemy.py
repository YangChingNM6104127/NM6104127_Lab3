import pygame
import math
import os
from settings import PATH

pygame.init()

#load enemy image
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))



class Enemy:
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        self.path = PATH
        self.path_index = 0
        self.move_count = 0
        self.stride = 1
        self.x, self.y = self.path[0]
        

    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
#       
        pygame.draw.rect(win,(0,255,0),[self.x - self.width // 2,self.y - self.height // 2-10,self.health,4])       #green
        pygame.draw.rect(win,(255,0,0),[self.x - self.width // 2,self.y - self.height // 2-10,self.max_health,4]) #red

    def move(self):
        """
        Enemy move toward path points every frame
        :return: None
        """
        
        start_x,start_y=self.path[self.path_index]                                #current position
        final_x,final_y=self.path[self.path_index+1]                              #the next step position
        distance_start_final=math.sqrt((final_x-start_x)**2+(final_y-start_y)**2) #distance of start and final points
        max_count=int(distance_start_final/self.stride)
        
        
        while self.move_count < max_count: # in the max_count, it is proper to move
            unit_vector_x = (final_x - start_x) / distance_start_final
            unit_vector_y = (final_y - start_y) / distance_start_final
            delta_x = unit_vector_x * self.stride
            delta_y = unit_vector_y * self.stride

            # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1
        
        
        self.path_index=self.path_index+1 #the next
        self.move_count=0                 #set to the orginal
        


class EnemyGroup:
    def __init__(self):
        self.gen_count = 0 
        self.gen_period = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = [Enemy()]  # don't change this line until you do the EX.3 
        

    def campaign(self):
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """

        # Hint: self.expedition.append(self.reserved_members.pop())
        # ...(to be done)

        if self.gen_count>=self.gen_period and not self.is_empty(): 
            self.expedition.append(self.reserved_members.pop())    #put the enemies from reserved_members to expedition(new enemy appears)
            self.gen_count = 0                                     #enemies pop out;then, the generating count needs to return to 0
        else:
            self.gen_count=self.gen_count+1
        
            

    def generate(self, num):
        """
        Generate the enemies in this wave-generate(3)
        :param num: enemy number
        :return: None
        """
        for j in range(num):
            self.reserved_members.append(Enemy(PATH))

    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)




